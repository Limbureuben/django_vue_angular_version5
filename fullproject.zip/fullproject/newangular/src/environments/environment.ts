// src/environments/environment.ts
export const environment = {
    production: false,
    apiUrl: 'http://127.0.0.1:8000',
    // apiUrl: 'http://192.168.1.124:8000/graphql/',
  };
  