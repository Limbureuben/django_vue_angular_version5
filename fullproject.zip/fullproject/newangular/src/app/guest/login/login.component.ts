import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService, LoginData } from '../../service/auth.service';
import { error } from 'node:console';
import { Subscription } from 'rxjs';
import { StorageService } from '../../service/storage/storage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})


export class LoginComponent implements OnInit{
  
  form!: FormGroup;
  registrationError: string = '';

  constructor(
    private authservice: AuthService,
    private fb: FormBuilder,
    private router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit(): void {
    // Initialize the form in ngOnInit
    this.form = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
 
  onLogin() {
    // Validate the form inputs
    if (!this.form.valid) {
      this.registrationError = 'Please fill in all the fields correctly';
      this.showFailure(this.registrationError);
      this.toastr.error(this.registrationError);
      return;
    }
  
    // Extract form values
    const { username, password } = this.form.value;
    console.log({ username, password });
  
    // Call the login service
    this.authservice.login(username, password).subscribe(
      (result) => {
        if (result.data?.loginUser?.success) {
          // Get user details and tokens from the response
          const user = result.data.loginUser.user;
  
          // Store tokens in local storage
          localStorage.setItem('access_token', user.accessToken);
          localStorage.setItem('refresh_token', user.refreshToken);
  
          this.toastr.success('Login successful!');
  
          // Redirect based on user role
          if (user.isSuperuser) {
            this.router.navigate(['/admin-dashboard']);
          } else {
            this.router.navigate(['/dashboard']);
          }
        } else {
  
          this.registrationError = result.data?.loginUser?.message || 'Login failed';
          this.toastr.error(this.registrationError);
          this.showFailure(this.registrationError);
        }
      },
      (error) => {

        if (error?.graphQLErrors?.length) {
          const message = error.graphQLErrors[0].message;
  
          if (message.includes('Email not verified')) {
            // Toast for unverified email
            this.toastr.warning('Please verify your email first.');
          } else {
            // Toast for other errors
            this.toastr.error(message);
          }
        } else {
          // General error fallback
          this.registrationError = 'An error occurred during login.';
          this.toastr.error(this.registrationError);
        }
        this.showFailure(this.registrationError);
      }
    );
  }

  showFailure(message: string) {
    console.error('Login Error:', message);
  }  
  
}



// export class LoginComponent implements OnInit {
//   form!: FormGroup;
//   registrationError: string = '';

//   constructor(
//     private authservice: AuthService,
//     private fb: FormBuilder,
//     private router: Router,
//     private toastr: ToastrService
//   ) {}

//   ngOnInit(): void {
//     this.form = this.fb.group({
//       username: ['', Validators.required],
//       password: ['', Validators.required],
//     });
//   }

//   onLogin() {
//     if (!this.form.valid) {
//       this.registrationError = 'Please fill in all the fields correctly.';
//       this.toastr.error(this.registrationError);
//       return;
//     }
  
//     const { username, password } = this.form.value;
  
//     this.authservice.login(username, password).subscribe({
//       next: (response) => {
//         const result = response.data?.loginUser;
  
//         console.log('GraphQL Response:', response); // Debugging response
//         if (result?.success) {
//           const user = result.user;
//           console.log('User Object:', user); // Debugging user object
  
//           // Store tokens
//           localStorage.setItem('access_token', user.accessToken);
//           localStorage.setItem('refresh_token', user.refreshToken);
  
//           this.toastr.success('Login successful!');
  
//           // Navigate based on role
//           if (user.isSuperuser === true) {
//             console.log('Superuser detected. Navigating to /admin-dashboard.');
//             this.router.navigate(['/admin-dashboard']);
//           } else {
//             console.log('Regular user detected. Navigating to /dashboard.');
//             this.router.navigate(['/dashboard']);
//           }
//         } else {
//           this.registrationError = result?.message || 'Login failed.';
//           console.error('Login failed:', this.registrationError);
//           this.toastr.error(this.registrationError);
//         }
//       },
//       error: (err) => {
//         const message = err?.graphQLErrors?.[0]?.message || 'An error occurred during login.';
//         this.registrationError = message;
//         console.error('GraphQL Error:', err); // Debugging error
//         this.toastr.error(message);
//       },
//     });
//   }  
// }