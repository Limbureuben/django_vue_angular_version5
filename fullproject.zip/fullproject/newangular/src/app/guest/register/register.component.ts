import { Component } from '@angular/core';
import { AuthService, RegisterData } from '../../service/auth.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';// Import ToastrService if you're using ngx-toastr
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { register } from 'module';
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
// export class RegisterComponent {
//   constructor(
//     private fb: FormBuilder,
//     private authservice: AuthService,
//     private router: Router,
//     private toastr: ToastrService
//   ) {}

//   formData = this.fb.group(
//     {
//       username: ['', Validators.required],
//       email: ['', [Validators.required, Validators.email]],
//       password: [
//         '',
//         [
//           Validators.required,
//           Validators.minLength(8),
//           passwordComplexityValidator(),
//         ],
//       ],
//       passwordConfirm: ['', Validators.required],
//     },
//     { validators: passwordMatchValidator() }
//   );

//   onSubmit() {
//     if (!this.formData.valid) {
//       this.formData.markAllAsTouched();
//       return;
//     }

//     const registrationData: RegisterData = {
//       email: this.formData.value.email as string,
//       password: this.formData.value.password as string,
//       username: this.formData.value.username as string,
//       passwordConfirm: this.formData.value.passwordConfirm as string,
//     };

//     this.authservice.registerUser(registrationData).subscribe({
//       next: (result) => {
//         const response = result.data.registerUser;
//         if (response.success) {
//           this.toastr.success(response.message, 'Success');
//           this.router.navigate(['/login']);
//         } else {
//           this.toastr.error(response.message, 'Registration Failed');
//         }
//       },
//       error: (error) => {
//         this.toastr.error('An unexpected error occurred. Please try again.', 'Error');
//       },
//     });
//   }

//   hasError(field: string, errorType: string): boolean {
//     const control = this.formData.get(field);
//     return control?.hasError(errorType) && control?.touched ? true : false;
//   }
// }

// /** Password Match Validator */
// export function passwordMatchValidator(): ValidatorFn {
//   return (control: AbstractControl): ValidationErrors | null => {
//     const password = control.get('password')?.value;
//     const confirmPassword = control.get('passwordConfirm')?.value;
//     return password && confirmPassword && password !== confirmPassword
//       ? { passwordMismatch: true }
//       : null;
//   };
// }

// /** passoword lazime iwe complex */
// export function passwordComplexityValidator(): ValidatorFn {
//   return (control: AbstractControl): ValidationErrors | null => {
//     const password = control.value || '';
//     const complexityRegex =
//       /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

//     return complexityRegex.test(password)
//       ? null
//       : {
//           passwordComplexity: true,
//         };
//   };
// }



export class RegisterComponent {
  formData: FormGroup;

  constructor(
    private fb: FormBuilder,
    private authservice: AuthService,
    private router: Router,
    private toastr: ToastrService
  ) {
    this.formData = this.fb.group(
      {
        username: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        password: [
          '',
          [
            Validators.required,
            Validators.minLength(8),
            this.passwordComplexityValidator(),
          ],
        ],
        passwordConfirm: ['', Validators.required],
      },
      { validators: this.passwordMatchValidator() }
    );
  }

  passwordMatchValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      const password = control.get('password')?.value;
      const confirmPassword = control.get('passwordConfirm')?.value;
      return password && confirmPassword && password !== confirmPassword
        ? { passwordMismatch: true }
        : null;
    };
  }

  passwordComplexityValidator() {
    return (control: AbstractControl): ValidationErrors | null => {
      const password = control.value || '';
      const complexityRegex =
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
      return complexityRegex.test(password)
        ? null
        : { passwordComplexity: true };
    };
  }

  onSubmit() {
    if (!this.formData.valid) {
      this.formData.markAllAsTouched();
      return;
    }

    const registrationData = this.formData.value;

    this.authservice.registerUser(registrationData).subscribe({
      next: (result) => {
        const response = result.data.registerUser;
        if (response.success) {
          this.toastr.success(response.message, 'Success');
          this.router.navigate(['/login']);
        } else {
          this.toastr.error(response.message, 'Registration Failed');
        }
      },
      error: (error) => {
        this.toastr.error('An unexpected error occurred. Please try again.', 'Error');
      },
    });
  }

  hasError(field: string, errorType: string): boolean {
    const control = this.formData.get(field);
    return control?.hasError(errorType) && control?.touched ? true : false;
  }
}