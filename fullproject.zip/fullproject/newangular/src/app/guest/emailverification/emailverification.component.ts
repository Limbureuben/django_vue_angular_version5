import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Apollo } from 'apollo-angular';
import { error } from 'console';
import { gql } from 'apollo-angular';


interface VerifyEmailResponse {
  success: boolean;
  message: string;
}


const VERIFY_EMAIL = gql`
  mutation VerifyEmail($email: String!, $token: String!) {
    verifyEmail(email: $email, token: $token) {
      success
      message
    }
  }
`;


@Component({
  selector: 'app-emailverification',
  templateUrl: './emailverification.component.html',
  styleUrl: './emailverification.component.scss'
})
export class EmailverificationComponent implements OnInit{

  constructor(private router: ActivatedRoute, private apollo: Apollo) {}

  ngOnInit(): void {
      this.router.queryParams.subscribe(params=>{
        const token = params['token'];
        const email = params['email'];

        //call verification email token
        this.apollo.mutate<{verifyEmail: VerifyEmailResponse}>({
          mutation: VERIFY_EMAIL,
          variables: {
            email,
            token
          }
        }).subscribe(({data})=>{
          if(data && data.verifyEmail) {
            console.log(data.verifyEmail.message);
          }
        },
        error => {
          console.error('Error verifying email', error)
        }
      )
      })
  }
}
