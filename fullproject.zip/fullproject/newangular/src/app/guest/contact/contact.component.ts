import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { AllUserService, MessageData } from '../../service/all-user.service';
import { Apollo } from 'apollo-angular';
import { response } from 'express';
import { Toast, ToastrService } from 'ngx-toastr';
import { emit } from 'process';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.scss'
})
export class ContactComponent {

contactForm: FormGroup;
lat: number | null = null;
lng: number | null = null;


constructor(
  private fb: FormBuilder, 
  private ContactService: AllUserService,
  private toastr: ToastrService
) {
    this.contactForm = this.fb.group({
      username: ['', Validators.required],
      email: ['',[Validators.required, Validators.email]],
      description: ['', Validators.required]
    });

    this.contactForm.get('username')?.valueChanges.subscribe((value)=>{
      this.contactForm.get('username')?.setValue(value.toUpperCase(), {emitEvent: false});
    });

    this.getUserLocation();
}


private getUserLocation(): void {
  if(navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      (position)=> {
        this.lat = position.coords.latitude;
        this.lng = position.coords.longitude;
      },
      (error) => {
        console.error('Error getting location:', error);
      }
    );
  }
}



onSubmit() {
  if(this.contactForm.valid && this.lat !== null && this.lng !== null ) {
    const FormData = {
      ...this.contactForm.value,
      lat: this.lat,
      lng: this.lng,
    };

    this.ContactService.sendMessage(FormData).subscribe({
      next: (response)=> {
        if(response.data.sendMessage.success) {
          this.toastr.success(response.data.sendMessage.message, 'success');
          this.contactForm.reset();
        } else {
          this.toastr.error('Failed to send message', 'Error');
        }
      },
      error: ()=> {
        this.toastr.error('An error occured while submitting the form', 'Error');
      },
    });
  } else {
    this.toastr.warning('Please fill out all fields correctly.', 'Warning');
  }
}
}

