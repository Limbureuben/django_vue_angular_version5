import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from '../shared/user_shared/header/header.component';
import { ApplicationComponent } from './application/application.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { FinancialComponent } from './financial/financial.component';
import { HeaderLoanComponent } from './header-loan/header-loan.component';
import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { HourlyWeatherComponent } from './hourly-weather/hourly-weather.component';
import { DailyWeatherComponent } from './daily-weather/daily-weather.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EmailverificationComponent } from './emailverification/emailverification.component';
import { VerifyEmailHandlerComponent } from './verify-email-handler/verify-email-handler.component';
import { authGuard as LoginAuth } from '../service/guards/auth.guard';
import { authGuard as PreventLogin } from '../service/noAuth/auth.guard';
import { authGuard as PreventLoginDashboard } from '../service/AuthAdmin/auth.guard';

const routes: Routes = [
  { path: 'register', component: RegisterComponent},
  { 
    path: 'login', component: LoginComponent,
    canActivate: [PreventLogin, PreventLoginDashboard],

  },
  { path: 'home', component: HomeComponent},
  { path: 'header', component: HeaderComponent},
  { path: 'application', component: ApplicationComponent},
  { path: 'userhome', component: UserhomeComponent},
  { path: 'financial', component: FinancialComponent},
  { path: 'header-loan', component: HeaderLoanComponent},
  { path: 'contact', component: ContactComponent},
  { path: 'about', component: AboutComponent},
  { path: 'daily-weather', component: DailyWeatherComponent},
  { path: 'hourly-weather', component: HourlyWeatherComponent},
  { 
    path: 'dashboard', component: DashboardComponent,
    canActivate: [LoginAuth],

  },
  { path: 'emailverification', component: EmailverificationComponent},
  { path: 'verification-success', component: VerifyEmailHandlerComponent}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GuestRoutingModule { }
