import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Apollo } from 'apollo-angular';
import {CreateApplicationMutation} from '../../../store/graphql';
import { ToastrService } from 'ngx-toastr';
import { AllUserService, ApplicationData } from '../../service/all-user.service';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrl: './application.component.scss'
})


export class ApplicationComponent {
  // formData: FormGroup;

  //   constructor(private fb: FormBuilder, private authservice: AuthService) {}

  //   ngOnInit() {
  //       this.formData = this.fb.group({
  //           username: ['', [Validators.required]],
  //           email: ['', [Validators.required, Validators.email]],
  //           region: ['', [Validators.required]],
  //           phoneNumber: ['', [Validators.required, Validators.pattern(/^\d+$/)]]
  //       });
  //   }

  //   onSubmit() {
  //       if (this.formData.valid) {
  //           this.authservice.submitForm(this.formData.value).subscribe(
  //               response => {
  //                   console.log('Form submitted successfully:', response);
  //               },
  //               error => {
  //                   console.error('Form submission error:', error);
  //               }
  //           );
  //       } else {
  //           console.error('Form is invalid');
  //       }
  //   }




}

