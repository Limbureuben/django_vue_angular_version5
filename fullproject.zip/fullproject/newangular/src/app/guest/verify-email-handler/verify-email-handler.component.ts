import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-verify-email-handler',
  template: `
    <div *ngIf="loading">Verifying your email, please wait...</div>
    <div *ngIf="errorMessage" class="error">{{ errorMessage }}</div>
  `,
  styleUrl: './verify-email-handler.component.scss'
})

export class VerifyEmailHandlerComponent implements OnInit{

  loading: boolean = true;
  errorMessage: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Get the token from the URL
    this.route.params.subscribe(params => {
      const token = params['token'];

      if (token) {
        // Make HTTP request to backend for token verification
        this.http.get(`http://192.168.1.124 10.0.3.1:8000/verify-email/${token}/`).subscribe({ //http://127.0.0.1:8000
          next: (response) => {
            this.loading = false;
            this.router.navigate(['/login']); // Redirect to login if successful
          },
          error: (error) => {
            this.loading = false;
            this.errorMessage = 'Verification failed. Please try again later.';
            this.router.navigate(['/login']); // Redirect to login even if failed
          }
        });
      } else {
        // Handle case where token is not provided
        this.loading = false;
        this.errorMessage = 'Invalid verification link.';
        this.router.navigate(['/login']); // Redirect to login if invalid link
      }
    });
  }
}
