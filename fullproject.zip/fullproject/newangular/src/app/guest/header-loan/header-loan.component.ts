import { Component } from '@angular/core';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-header-loan',
  templateUrl: './header-loan.component.html',
  styleUrl: './header-loan.component.scss'
})
export class HeaderLoanComponent {

  isMenuOpen: Boolean = false;

  toggleMenu() {
    this.isMenuOpen = !this.isMenuOpen;
  }

  constructor(private authservice: AuthService) {}

  onLogout () {
    this.authservice.logout();
  }
}
