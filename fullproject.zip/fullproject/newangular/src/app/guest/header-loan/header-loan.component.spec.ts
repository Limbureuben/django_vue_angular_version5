import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderLoanComponent } from './header-loan.component';

describe('HeaderLoanComponent', () => {
  let component: HeaderLoanComponent;
  let fixture: ComponentFixture<HeaderLoanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HeaderLoanComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HeaderLoanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
