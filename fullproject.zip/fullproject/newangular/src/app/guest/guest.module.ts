import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GuestRoutingModule } from './guest-routing.module';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from '../shared/user_shared/header/header.component';
import { ApplicationComponent } from './application/application.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { FinancialComponent } from './financial/financial.component';
import { HeaderLoanComponent } from './header-loan/header-loan.component';
import { ContactComponent } from './contact/contact.component';
import { AboutComponent } from './about/about.component';
import { DailyWeatherComponent } from './daily-weather/daily-weather.component';
import { HourlyWeatherComponent } from './hourly-weather/hourly-weather.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EmailverificationComponent } from './emailverification/emailverification.component';
import { VerifyEmailHandlerComponent } from './verify-email-handler/verify-email-handler.component';


@NgModule({
  declarations: [
    RegisterComponent,
    LoginComponent,
    HomeComponent,
    HeaderComponent,
    ApplicationComponent,
    UserhomeComponent,
    FinancialComponent,
    HeaderLoanComponent,
    ContactComponent,
    AboutComponent,
    DailyWeatherComponent,
    HourlyWeatherComponent,
    DashboardComponent,
    EmailverificationComponent,
    VerifyEmailHandlerComponent,
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    GuestRoutingModule
  ]
})
export class GuestModule { }
