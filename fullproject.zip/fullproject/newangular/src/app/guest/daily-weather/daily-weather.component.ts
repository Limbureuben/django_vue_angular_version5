import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../../service/weather.service';
import { Chart } from 'chart.js';

@Component({
  selector: 'app-daily-weather',
  templateUrl: './daily-weather.component.html',
  styleUrl: './daily-weather.component.scss'
})
export class DailyWeatherComponent implements OnInit{
  weatherData: any = {};
  temperatureChart: any;
  humidityChart: any;

  constructor(private weatherService: WeatherService) { }

  ngOnInit(): void {
  }

  createCharts(): void {
    const temperatureCtx = document.getElementById('temperatureChart') as HTMLCanvasElement;
    const humidityCtx = document.getElementById('humidityChart') as HTMLCanvasElement;

    if (this.weatherData) {
      // Temperature chart
      this.temperatureChart = new Chart(temperatureCtx, {
        type: 'line',
        data: {
          labels: this.weatherData.temperature_trend.timestamps,
          datasets: [{
            label: 'Temperature',
            data: this.weatherData.temperature_trend.temperatures,
            borderColor: '#FF6384',
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            fill: true
          }]
        }
      });

      this.humidityChart = new Chart(humidityCtx, {
        type: 'line',
        data: {
          labels: this.weatherData.humidity_trend.timestamps,
          datasets: [{
            label: 'Humidity',
            data: this.weatherData.humidity_trend.humidities,
            borderColor: '#36A2EB',
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            fill: true
          }]
        }
      });
    }
  }
}
