import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../../service/weather.service';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-hourly-weather',
  templateUrl: './hourly-weather.component.html',
  styleUrl: './hourly-weather.component.scss'
})
export class HourlyWeatherComponent implements OnInit {

  public hourlyData: any[] = [];
  currentWeather: any;

  constructor(private weatherService: WeatherService) {
    Chart.register(...registerables);
  }


  ngOnInit(): void {
    this.weatherService.getHourlyAverageSummary().subscribe(data => {
      this.hourlyData = data;
      this.getCurrentWeather();
      this.createHourlyChart();
    });
  }

  getCurrentWeather(): void {
    this.weatherService.getCurrentWeather().subscribe(
      data => {
        this.currentWeather = data;
        console.log(this.currentWeather);
        console.log('Current Weather:', this.currentWeather);
      },
      error => {
        console.error('Error fetching current weather data:', error);
      }
    );
  }

  createHourlyChart(): void {
    const ctx = document.getElementById('hourlyChart') as HTMLCanvasElement;
    const labels = this.hourlyData.map(d => new Date(d.Date).toLocaleTimeString());
    const tempData = this.hourlyData.map(d => d['Temperature Average']);
    const humidityData = this.hourlyData.map(d => d['Humidity Average']);

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Temperature (°C)',
            data: tempData,
            borderColor: '#FF6384',
            backgroundColor: 'rgba(255, 99, 132, 0.2)',
            fill: true
          },
          {
            label: 'Humidity (%)',
            data: humidityData,
            borderColor: '#36A2EB',
            backgroundColor: 'rgba(54, 162, 235, 0.2)',
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Time'
            }
          },
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Value'
            }
          }
        }
      }
    });
  }
}
