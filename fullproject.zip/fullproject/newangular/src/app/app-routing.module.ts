import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminhomeComponent } from './admin/adminhome/adminhome.component';
import { HeaderComponent } from './shared/user_shared/header/header.component';
import { HeaderLoanComponent } from './guest/header-loan/header-loan.component';
import { MapComponent } from './admin/map/map.component';

const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full'},
  {
    path: "app",
    component: AdminhomeComponent,
    loadChildren: () =>
    import('./admin/admin.module').then((m) => m.AdminModule)
  },

  {
    path: "app",
    component: HeaderComponent,
    loadChildren: () =>
    import('./admin/admin.module').then((m) => m.AdminModule)
  },

  {
    path: "app",
    component: HeaderLoanComponent,
    loadChildren: () =>
    import('./admin/admin.module').then((m) => m.AdminModule)
  },

  {
    path: "app",
    component: MapComponent,
    loadChildren: () =>
    import('./admin/admin.module').then((m) => m.AdminModule)
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
