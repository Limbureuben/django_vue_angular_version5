import { Injectable, OnInit } from '@angular/core';
import { from, Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
import { GET_ALL_USERS_QUERY, SEND_MESSAGE, GET_ALL_MESSAGES, GET_MESSAGE_COUNT, DELETE_MESSAGE, FETCH_PRODUCTS } from '../../store/graphql';
import { ToastrService } from 'ngx-toastr';
import { CreateApplicationMutation, LoginMutation, AdminMutation, CreateMessageMutation  } from '../../store/graphql';
import { Apollo, gql, TypedDocumentNode } from 'apollo-angular';
import { map } from 'rxjs/operators';

export interface ApplicationData {
  username: string;
  email: string;
  region: string;
  phoneNumber: string;
}

export interface Updatedata {
  username: string;
  email: string;
}

interface Product {
  imageUrl: string;
}

export interface MessageData {
  topic: string;
  published_date: string;
  text: string;
}

export interface User {
  id: number;
  username: String;
  email: String;
}


@Injectable({
  providedIn: 'root'
})
export class AllUserService {
  private tokenKey = 'authToken';

  constructor (
    private router: Router,
    private authService: AuthService,
    private apollo: Apollo,
    private toastr: ToastrService


  ) {};

  ensureAdmin() {

  }


getAllUsers(): Observable<any> {
  return this.apollo
  .watchQuery({
    query: GET_ALL_USERS_QUERY,
  })
  .valueChanges;
}


application(userData: ApplicationData){
  this.apollo.mutate({
    mutation:CreateApplicationMutation,
    variables:{
      input: userData
    }
  }).subscribe({
    next: (result) => {
      console.log('Registration successful:', result);
      this.toastr.success('Registration successful');
      this.router.navigate(['/userhome']);
      // handle successful registration, e.g., redirect to login
    },
    error: (error) => {
      console.error('Registration error:', error);
      this.showFailure(error)
    }
  });
}

// messagesent(userData: MessageData){
//   this.apollo.mutate({
//     mutation:CreateMessageMutation,
//     variables:{
//       input: userData
//     }
//   }).subscribe({
//     next: (result) => {
//       console.log('message sent!!:', result);
//       this.toastr.success('Registration successful');
//       this.router.navigate(['/userhome']);
//       // handle successful registration, e.g., redirect to login
//     },
//     error: (error) => {
//       console.error('Registration error:', error);
//       this.showFailure(error)
//     }
//   });
// }


showFailure(message:string) {
  this.toastr.error(message);
}

sendMessage(input: {username: string, email: string, description: string, lat: number, lng: number}): Observable<any> {
  return this.apollo.mutate({
    mutation: SEND_MESSAGE,
    variables: { input },
  })
}

getMessages(): Observable<any> {
  return this.apollo.query({
    query: GET_ALL_MESSAGES
  })
}

getMessageCount(): Observable<any> {
  return this.apollo.watchQuery<{ messageCount: number}>({
    query: GET_MESSAGE_COUNT,
  }).valueChanges;
}

deleteMessage(id:string): Observable<any> {
 return this.apollo.mutate({
  mutation: DELETE_MESSAGE,
  variables: {id},
 })
}



fetchProducts(): Observable<any> {
  return this.apollo.watchQuery({
    query: FETCH_PRODUCTS,
  }).valueChanges;
}


}

