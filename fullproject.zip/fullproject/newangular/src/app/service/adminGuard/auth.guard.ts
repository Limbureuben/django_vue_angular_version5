// import { CanActivateFn } from '@angular/router';

// export const authGuard: CanActivateFn = (route, state) => {
//   return true;
// };



// import { CanActivateFn } from '@angular/router';
// import { inject } from '@angular/core'; import { Router } from '@angular/router';
// import { jwtDecode } from 'jwt-decode';

// export const adminGuard: CanActivateFn = (route, state) => {
//   const router = inject(Router);
//   const token = localStorage.getItem('access_token');

//   if (token) {
//     try {
//       const decodedToken: any = jwtDecode(token);

//       // Log decoded token to check if isSuperuser exists
//       console.log('Decoded Token:', decodedToken);

//       // Check if the token contains the isSuperuser field
//       if (decodedToken.is_superuser) {
//         return true;
//          // Allow access for superusers
//       } else {
//         // Redirect regular users to their dashboard or any other route
//         router.navigate(['/dashboard']);
//         return false;
//       }
      
//     } catch (error) {
//       console.error('Token decoding failed:', error);
//       router.navigate(['/login']);
//       return false;
//     }
//   } else {
//     router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
//     return false;
//   }
// };



import { CanActivateFn } from '@angular/router';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { jwtDecode } from 'jwt-decode';

export const adminGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);

  // angalia kama local storage in exist
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('access_token');

    if (token) {
      try {

        const decodedToken: any = jwtDecode(token);

        const isTokenExpired = decodedToken.exp && decodedToken.exp * 1000 < Date.now();

        if (!isTokenExpired) {

          return true;
        } else {

          console.warn('Token has expired');
          router.navigate(['/home'], { queryParams: { returnUrl: state.url } }); // Redirect to login
          return false;
        }
      } catch (error) {
        console.error('Error decoding token:', error);
        router.navigate(['/home'], { queryParams: { returnUrl: state.url } }); // Redirect to login
        return false;
      }
    }
  }

  router.navigate(['/home'], { queryParams: { returnUrl: state.url } });
  return false;
};



