import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);

  // Ensure we're not running on SSR (server-side)
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('access_token');

    // Check if the user is authenticated
    if (token) {
      // Prevent navigation to the login page if the user is already logged in
      if (state.url === '/login') {
        router.navigate(['/admin-dashboard']); // Redirect to the dashboard if logged in
        return false;
      }
      // Allow access to the protected routes
      return true;
    }
  }

  // If no token exists, restrict access to protected routes and redirect to login
  if (state.url !== '/login') {
    router.navigate(['/login']); // Redirect to login if trying to access a protected route
    return false;
  }

  return true;
};
