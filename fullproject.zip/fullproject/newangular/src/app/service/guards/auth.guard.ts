import { CanActivateFn } from '@angular/router';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { jwtDecode } from 'jwt-decode';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);

  // angalia kama local storage in exist
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('access_token');

    if (token) {
      try {

        const decodedToken: any = jwtDecode(token);

        const isTokenExpired = decodedToken.exp && decodedToken.exp * 1000 < Date.now();

        if (!isTokenExpired) {

          return true;
        } else {

          console.warn('Token has expired');
          router.navigate(['/login'], { queryParams: { returnUrl: state.url } }); // Redirect to login
          return false;
        }
      } catch (error) {
        console.error('Error decoding token:', error);
        router.navigate(['/login'], { queryParams: { returnUrl: state.url } }); // Redirect to login
        return false;
      }
    }
  }

  router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
  return false;
};