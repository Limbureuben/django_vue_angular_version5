import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { lastValueFrom, Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Apollo, TypedDocumentNode } from 'apollo-angular';
import { CreateRegistration, LoginMutation, AdminMutation, REGISTER_MUTATION, LOGIN_MUTATION, LOGIN_MUTATION_USER } from '../../store/graphql';
import { ToastrService } from 'ngx-toastr';
import { GET_ALL_USERS_QUERY } from '../store/entities/dashboard/dashboard.graphql';
import { response } from 'express';
import { error } from 'console';
import { Token } from 'graphql';
import { StorageService } from './storage/storage.service';
import { promises } from 'dns';
import { MatSnackBar } from '@angular/material/snack-bar';

export interface RegisterData {
  username: string;
  email: string;
  password: string;
  passwordConfirm: string;
}



export interface userData {
  username: string;
  email: string;
  password: string;
}

export interface userDetails {
  username: string;
  email: string;
  password: string,
  passwordConfirm: string;
}

export interface Data {
  username: string;
  password: string;
}

export interface LoginData {
  username: string;
  password: string;
}

export interface AdminData {
  username: String;
  password: String;
}

export interface LoginResponse {
  loginUser: {
    success: boolean;
    token: string;
  };
}


@Injectable({
  providedIn: 'root'
})



export class AuthService {
  adminlogout() {
    throw new Error('Method not implemented.');
  }
  getUserProfile() {
    throw new Error('Method not implemented.');
  }

  static isLoggedIn() {
    throw new Error('Method not implemented')
  }
 
  request(GET_ALL_USERS_QUERY: TypedDocumentNode<unknown, unknown>): any {
    throw new Error('Method not implemented.');
  }

  private apiUrl = environment.apiUrl;
  constructor(

    private apollo: Apollo, 
    private router: Router,
    private storage: StorageService,
    private toastr: ToastrService,
    private snackBar: MatSnackBar ) {}

  registerUser(userData: RegisterData): Observable<any> {
    return this.apollo.mutate({
      mutation: REGISTER_MUTATION,
      variables: {
        input: userData,
      },
    });
  }


login(username: string, password: string): Observable<any> {
  return this.apollo.mutate({
    mutation: LOGIN_MUTATION_USER,
    variables: {
      input: {
        username,
        password,
      },
    },
  });
}



logout() {
  localStorage.removeItem('access_token');
  console.log('Token after logout:', localStorage.getItem('access_token'));
  this.snackBar.open('You have been logged out.', 'Close', { duration: 3000 });
  this.router.navigate(['']);
}
    

  loginadmin(loginDetails: AdminData) {
    this.apollo.mutate({
      mutation: AdminMutation,
      variables: {
        input: loginDetails
      }
    }).subscribe(
      {
        next: (res)=> {
          let mydata : any = res.data
            if(mydata?.adminLogin.success) {
              this.toastr.success('success login');
              this.router.navigate(['/admin-dashboard']);
            }
            else{
              this.toastr.error('wrong credentials');
            }
        },
        error: (e)=>{console.error(e)},
      }
    )
  }

  showSuccess(message:string) {
    this.toastr.success(message);
  }

  showFailure(message:string) {
    this.toastr.error(message);
  }


  private handleError(error: any): Observable<never> {
    // Handle the error appropriately
    console.error('An error occurred:', error);
    return throwError(() => new Error('Something went wrong; please try again later.'));
  }

  
}

