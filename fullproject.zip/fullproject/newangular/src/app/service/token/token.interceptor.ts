import { HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { StorageService } from '../storage/storage.service';
import { inject } from '@angular/core';
import { Observable } from 'rxjs';

export class TokenInterceptor implements HttpInterceptor {
  private storage = inject(StorageService);

  intercept(
    req: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<any> {
    const token = this.storage.get('token');

    if (token) {
      req = req.clone({
        setHeaders: {
          Authorization: `Jwt ${token}`
        },
      });
    }
  
    return next.handle(req);
  }

}
