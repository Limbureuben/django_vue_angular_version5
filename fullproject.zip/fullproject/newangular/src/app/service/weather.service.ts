import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  private apiUrl = 'http://172.17.17.159:8000'; // Adjust URL as necessary

  constructor(private http: HttpClient) {}

  getHourlyAverageSummary(): Observable<any> {
    return this.http.get<any>(this.apiUrl + "/api/hourly-average-summary/");
  }
  getCurrentWeather(): Observable<any> {
    const url = `${this.apiUrl}/api/current-weather/`;
    return this.http.get<any>(url);
  }
}
