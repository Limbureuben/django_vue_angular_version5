import { Component, OnInit } from '@angular/core';
import { AllUserService, User} from '../../service/all-user.service';
import { Store } from '@ngrx/store';
import { GetDashboardData } from '../../store/entities/dashboard/dashboard.actions';
import { Observable } from 'rxjs';
import { Dashboard } from '../../store/entities/dashboard/dashboard.model';
import { selectDashboardDatas, selectModifiedDashboardDatas } from '../../store/entities/dashboard/dashboard.selectors';
import {AppState} from '../../store/reducers';
import { MatDialog } from '@angular/material/dialog';
import { EditUserDialogComponent } from '../edit-user-dialog/edit-user-dialog.component';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrl: './homepage.component.scss'
})
export class HomepageComponent implements OnInit{

users: User[] = [];

constructor(
  private allUser: AllUserService,
  private store:Store<AppState>,
  public dialog: MatDialog
) {};

ngOnInit(): void {
  this.allUser.getAllUsers().subscribe(
    (result) => {
      this.users = result.data.users;
    },
    (error) => {
      console.error('there is an error fetching the users', error)
    }
  );
}

openEditModal(userId: number): void {
  console.log('Edit user with ID:', userId);
  // Logic for opening the modal goes here
}

}
