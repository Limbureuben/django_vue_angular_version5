import { Component, OnInit } from '@angular/core';
import { AllUserService } from '../../service/all-user.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.scss']
})
export class MessageComponent implements OnInit {
  messages: any[] = [];
  selectedMessage: any = null;
  loading = true;
  error: string | null = null;

  showLocationModal = false;
  locationLat: number | null = null;
  locationLng: number | null = null;

  constructor(private messageService: AllUserService, private toastr: ToastrService) {}

  ngOnInit() {
    this.fetchMessages();
  }

  // fetchMessages() {
  //   this.messageService.getMessages().subscribe({
  //     next: (response: any) => {
  //       this.messages = response?.data?.allMessage || [];
  //       this.loading = false;
  //     },
  //     error: () => {
  //       this.error = 'Failed to fetch messages';
  //       this.loading = false;
  //     }
  //   });
  // }

  fetchMessages() {
    this.messageService.getMessages().subscribe({
      next: (response: any) => {
        const apiMessages = response?.data?.allMessage || [];
        
        // Check if test message is already in the array, otherwise add it back
        if (!this.messages.some(msg => msg.id === 'test-1')) {
          this.messages.unshift({
            id: 'test-1',
            username: 'Test User',
            email: 'test.user@example.com',
            date: new Date(),
            lat: 37.7749,
            lng: -122.4194,
            description: 'This is a test message for testing purposes.',
          });
        }
        
        // Append new messages
        this.messages = [...this.messages, ...apiMessages];
        this.loading = false;
      },
      error: (error) => {
        this.error = 'Failed to fetch messages';
        this.loading = false;
      },
    });
  }
  

    openMessageModal(msg: any): void {
    this.selectedMessage = msg;
  }

  closeMessageModal(): void {
    this.selectedMessage = null;
  }

  openLocationModal(lat: number, lng: number): void {
    this.locationLat = lat;
    this.locationLng = lng;
    this.showLocationModal = true;
  }

  closeLocationModal(): void {
    this.showLocationModal = false;
    this.locationLat = null;
    this.locationLng = null;
  }

  deleteMessage(id: string): void {
    this.messageService.deleteMessage(id).subscribe({
      next: (response) => {
        if (response.data.deleteMessage.success) {
          this.toastr.success(response.data.deleteMessage.message, 'Delete message success!');
          this.messages = this.messages.filter((msg) => msg.id !== id);
        } else {
          this.toastr.error('Failed to delete the message.', 'Error');
        }
      },
      error: () => {
        this.toastr.error('An error occurred while deleting the message.', 'Error');
      }
    });
  }
}
