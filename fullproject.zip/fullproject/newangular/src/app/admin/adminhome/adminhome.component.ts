import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../service/auth.service';
import { AllUserService } from '../../service/all-user.service';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.scss'
})
export class AdminhomeComponent implements OnInit {
  messageCount: number = 0;

  constructor(private authservice: AuthService, private messageService: AllUserService) {}

  ngOnInit(): void {
    this.messageService.getMessageCount().subscribe({
      next: (result)=>{
        this.messageCount = result.data.messageCount;
      },
      error: (err) => {
        console.error('Error fetching message count', err);
      }
    });
  }

  onLogout() {
    this.authservice.logout()
  }

}
