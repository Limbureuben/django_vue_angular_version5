import { Component, Input, OnInit, OnChanges, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit, OnChanges {
  @Input() lat: number | null = null;
  @Input() lng: number | null = null;
  map!: L.Map;

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId) && this.lat && this.lng) {
      this.loadLeafletAndInitMap();
    }
  }

  ngOnChanges(): void {
    if (isPlatformBrowser(this.platformId) && this.lat && this.lng && this.map) {
      this.map.setView([this.lat, this.lng], 13);
      if (this.map) {
        this.map.invalidateSize(); // Ensure map is resized properly when full-screen
      }
    }
  }

  async loadLeafletAndInitMap(): Promise<void> {
    const L = await import('leaflet');
    const mapElement = document.getElementById('map') as HTMLElement;

    if (mapElement && this.lat && this.lng) {
      this.map = L.map(mapElement).setView([this.lat, this.lng], 13);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      }).addTo(this.map);

      L.marker([this.lat, this.lng]).addTo(this.map)
        .bindPopup('User Location')
        .openPopup();
    }
  }
}
