import { Component, OnInit } from '@angular/core';
import { AllUserService } from '../../service/all-user.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrl: './product.component.scss'
})
export class ProductComponent implements OnInit {
  products: any[] = [];
  loading: boolean = true;
  error: any;

constructor(private ProductService: AllUserService) {}

ngOnInit(): void {
  this.ProductService.fetchProducts().subscribe(
    (result: any) => {
      this.products = result.data.products;
      this.loading = false;
    },

    (err) => {
      this.error = err;
      this.loading = false;
    }
  );
}



}
