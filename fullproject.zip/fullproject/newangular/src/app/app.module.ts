import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GraphQLModule } from './graphql.module';
import { RouterModule } from '@angular/router';
import { provideHttpClient, withInterceptorsFromDi, withFetch } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule, NoopAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { GuestModule } from './guest/guest.module';
import { AdminModule } from './admin/admin.module';
import { StoreModule } from '@ngrx/store';
import { reducers, metaReducers } from './store/reducers';
import { EffectsModule } from '@ngrx/effects';
import { DashboardEffects } from './store/entities/dashboard/dashboard.effects';
import { Apollo, ApolloModule } from 'apollo-angular';
import { UsersEffects } from './store/entities/users/users.effects';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MatDialogModule } from '@angular/material/dialog';




@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    RouterModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,

    GraphQLModule,
    GuestModule,
    AdminModule,
    MatDialogModule,
    ToastrModule.forRoot({ // ToastrModule added
      positionClass: 'toast-top-right',
      timeOut: 3000,
      closeButton: true,
      progressBar: true,
      preventDuplicates: true,
    }),
    StoreModule.forRoot(reducers, { metaReducers}),
    EffectsModule.forRoot([DashboardEffects, UsersEffects]),
    ApolloModule,
  ],
  providers: [
    provideHttpClient(withInterceptorsFromDi()),
    provideClientHydration(),
    provideAnimations(),
    Apollo,
    provideAnimationsAsync(),
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
