// src/app/graphql.module.ts
import { NgModule } from '@angular/core';
import { APOLLO_OPTIONS, ApolloModule } from 'apollo-angular';
import { HttpLink } from 'apollo-angular/http';
import { InMemoryCache } from '@apollo/client/core';

@NgModule({
  imports: [ApolloModule],
  providers: [
    {
      provide: APOLLO_OPTIONS,
      useFactory: (httpLink: HttpLink) => {
        return {
          cache: new InMemoryCache(),
          link: httpLink.create({
            uri: 'http://127.0.0.1:8000/graphql/',
            // uri: 'http://192.168.1.124:8000/graphql/',
          }),
        };
      },
      deps: [HttpLink],
    },
  ],
})
export class GraphQLModule {}