import { isDevMode } from '@angular/core';
import {
  ActionReducer,
  ActionReducerMap,
  createFeatureSelector,
  createSelector,
  MetaReducer
} from '@ngrx/store';
import * as fromDashboard from '../entities/dashboard/dashboard.reducer';
import * as fromUsers from '../entities/users/users.reducer';
// import { Dashboard } from '../entities/dashboard/dashboard.model';

export const dashboardsFeatureKey = 'dashboard';

export interface AppState {

  [fromDashboard.dashboardsFeatureKey]: fromDashboard.State;
  [fromUsers.usersesFeatureKey]: fromUsers.State;
}

export const reducers: ActionReducerMap<AppState> = {

  [fromDashboard.dashboardsFeatureKey]: fromDashboard.reducer,
  [fromUsers.usersesFeatureKey]: fromUsers.reducer,
};


export const metaReducers: MetaReducer<AppState>[] = isDevMode() ? [] : [];
// export const appState = (state:State) => state;