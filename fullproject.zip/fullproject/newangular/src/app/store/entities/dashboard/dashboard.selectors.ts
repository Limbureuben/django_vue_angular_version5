import { createFeatureSelector, createSelector} from '@ngrx/store';
import {AppState} from '../../reducers';
import * as fromReducer from '../dashboard/dashboard.reducer';
import { Dashboard } from './dashboard.model';

export const currentState = (state:AppState) => state[ fromReducer.dashboardsFeatureKey]

export const selectDashboardDatas = createSelector(
    currentState,fromReducer.selectAll
);

export const selectModifiedDashboardDatas = createSelector(
    selectDashboardDatas,
    (datas) => {
        return datas.map((data:Dashboard)=>{
            return{
                ...data,
            }
        })
    }
)
