export interface Dashboard {
  id: string;
  username: string;
  email: string;
  __typename:string;
}
