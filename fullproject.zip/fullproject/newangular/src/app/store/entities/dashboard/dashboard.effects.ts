import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { Apollo } from 'apollo-angular';

import{AppState} from '../../reducers'
import { map, switchMap } from 'rxjs';
import * as fromActions from '../dashboard/dashboard.actions';
import * as fromGraphql from '../dashboard/dashboard.graphql';


@Injectable()
export class DashboardEffects {

  getDashboardDatas$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(fromActions.GetDashboardData),
      switchMap((action) => {
        // Ensure that `this.apollo.query` is valid
        if (!this.apollo.query) {
          console.error('Apollo query method is not defined');
          return []; // Return an empty array or an empty observable
        }

        return this.apollo.query({
          query: fromGraphql.GET_ALL_USERS_QUERY,
          fetchPolicy: 'network-only',
        }).pipe(
          map(({ data }: any) => {
            console.log('Received data:', data.allRegistrations);
            // Handle the data appropriately here
            
            this.store.dispatch(fromActions.DashboardActions.loadDashboards({dashboards:data.allRegistrations}))
          }),
          // Add any additional operators if needed
        );
      }),
      // Handle errors or add side-effects if necessary
    );
  }, { dispatch: false });


  constructor(
    private actions$: Actions,
    private apollo:Apollo,
    private store: Store<AppState>, 
  ) {}
}
