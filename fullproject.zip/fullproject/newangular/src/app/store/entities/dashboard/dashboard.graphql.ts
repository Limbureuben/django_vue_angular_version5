import { gql } from "apollo-angular";

export const GET_ALL_USERS_QUERY = gql`
query MyQuery {
  allRegistrations {
    email
    id
    username
  }
}

`;