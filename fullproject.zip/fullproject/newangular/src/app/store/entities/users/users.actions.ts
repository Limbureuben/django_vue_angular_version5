import { createAction, createActionGroup, emptyProps, props } from '@ngrx/store';
import { Update } from '@ngrx/entity';

import { userInput, Users } from './users.model';

export const UsersActions = createActionGroup({
  source: 'Users/API',
  events: {
    'Load Userss': props<{ userss: Users[] }>(),
    'Add Users': props<{ users: Users }>(),
    'Upsert Users': props<{ users: Users }>(),
    'Add Userss': props<{ userss: Users[] }>(),
    'Upsert Userss': props<{ userss: Users[] }>(),
    'Update Users': props<{ users: Update<Users> }>(),
    'Update Userss': props<{ userss: Update<Users>[] }>(),
    'Delete Users': props<{ id: string }>(),
    'Delete Userss': props<{ ids: string[] }>(),
    'Clear Userss': emptyProps(),
  }
});

// CUSTOM   
export const updateUser = createAction(
  '[Users/API] edit User',
    props<{input:userInput}>()
)