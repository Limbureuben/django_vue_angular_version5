export interface Users {
  id: string;
}

export interface userInput {
  id: string;
  username: string;
  email: string;
}