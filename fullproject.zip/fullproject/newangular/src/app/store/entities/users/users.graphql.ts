import { gql } from "@apollo/client/core";


// export const UPDATE_USER = gql 
// `mutation updateUser($input:UpdateRegistrationInput!) {
//   updateRegistration(input: $input) {
//     message
//     success
//   }
// }`

export const UPDATE_USER = gql 
`mutation updateUser($input:UpdateRegistrationInput!) {
  updateRegistration(input: $input) {
    message
    success
  }
}
`

