import { Injectable, input } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Apollo } from 'apollo-angular';
import { AppState } from '../../reducers';
import { Store } from '@ngrx/store';

import * as fromActions from '../users/users.actions';
import * as fromGraphql from '../users/users.graphql';
import { map, switchMap } from 'rxjs';

@Injectable()
export class UsersEffects {

  updateUser$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(fromActions.updateUser),
      switchMap((action) => {
        // Ensure that `this.apollo.query` is valid
        if (!this.apollo.query) {
          console.error('Apollo query method is not defined');
          return []; // Return an empty array or an empty observable
        }

        return this.apollo.query({
          query: fromGraphql.UPDATE_USER,
          fetchPolicy: 'network-only',
          variables:{
            input:action.input
          }
        }).pipe(
          map(({ data }: any) => {
            console.log('Received data:', data.allRegistrations);
            // Handle the data appropriately here
            
            this.store.dispatch(fromActions.UsersActions.updateUsers({users:data}))
          }),
          // Add any additional operators if needed
        );
      }),
      // Handle errors or add side-effects if necessary
    );
  }, { dispatch: false });

  constructor(
    private actions$: Actions,
    private apollo:Apollo,
    private store: Store<AppState>,
  ) {}
}
