import { gql } from "apollo-angular";

 export const CreateRegistration = gql`
  mutation CreateRegistration($input: CreateRegistrationInput!) {
  createRegistration(input: $input) {
    registration {
      id
      username
      email
    }
  }
}
`;

export const CreateApplicationMutation = gql`
mutation createApplication($input: CreateApplicationInput!) {
  createApplication(input: $input) {
    application {
      applicationDate
      email
      id
      phoneNumber
      region
      username
    }
  }
}
`;

export const CreateMessageMutation =gql`
mutation createMessage($input: CreateMessage!) {
  createMessage(input: $input) {
  message {
      id
      text
      topic
    }
  }
}
`;


export const UpdateRegistration = gql`
mutation updateRegistration($input: UpdateRegistrationInput!) {
  updateRegistration(input: $input) {
    registration {
      email
      id
      username
    }
  }
}
`;

  export const LoginMutation = gql`
  mutation login($input: LoginInput!) {
    login(input: $input) {
      success
    }
  }
`;

export const AdminMutation = gql`
mutation adminLogin($input: AdminInput!) {
  adminLogin(input: $input) {
    success
  }
}
`;

export const GET_ALL_USERS_QUERY = gql`
  query MyQuery {
    users {
      id
      username
      email
    }
  }
`;


// export const SEND_MESSAGE = gql`
//   mutation SendMessage($input: MessageInputObject!) {
//     sendMessage(input: $input) {
//       message
//       success
//     }
//   }
// `;


export const SEND_MESSAGE = gql`
  mutation SendMessage($input: MessageInputObject!) {
    sendMessage(input: $input) {
      message
      success
      messages {
        id
        username
        email
        description
        date
        lat
        lng
      }
    }
  }
`;




export const GET_ALL_MESSAGES = gql`
  query MyQuery {
    allMessage {
      description
      date
      email
      id
      username
    }
  }
`;

export const GET_MESSAGE_COUNT = gql`
  query MyQuery {
    messageCount
  }
`;

export const DELETE_MESSAGE = gql`
  mutation MyMutation($id: ID!) {
    deleteMessage(id: $id) {
      message
      success
    }
  }
`;



export const REGISTER_MUTATION = gql`
  mutation RegisterUser($input: UserRegistrationInputObject!) {
    registerUser(input: $input) {
      message
      success
      user {
        email
        id
        username
      }
    }
  }
`;


export const LOGIN_MUTATION_USER = gql`
  mutation LoginUser($input: UserLoginInputObject!) {
    loginUser(input: $input) {
      success
      message
      user {
        id
        username
        email
        accessToken
        refreshToken
        isSuperuser
      }
    }
  }
`;



export const LOGIN_MUTATION = gql`
  mutation loginUser($username: String!, $password: String!) {
    loginUser(username: $username, password: $password) {
      success
      token
    }
  }
`;

const VERIFY_EMAIL = gql`
  mutation VerifyEmail($email: String!, $token: String!) {
    verifyEmail(email: $email, token: $token) {
      success
      message
    }
  }
`;


export const FETCH_PRODUCTS = gql`
  query MyQuery {
    products {
      dateUploaded
      discountPercentage
      imageUrl
      name
      price
    }
  }
`;

