/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./src/**/*.{html,js}"],
    theme: {
        extend: {
            colors: {
                aquinium: '#00A3E0',
                lightseagreen: '#20B2AA',
            },
        },
    },
    plugins: [],
}