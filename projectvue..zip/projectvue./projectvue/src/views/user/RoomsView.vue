<template>
    <div>
      <UserHeader />
      <div class="rooms-container">
        <div v-if="loading">Loading rooms...</div>
        <div v-else-if="error">{{ error }}</div>
  
        <div v-else class="rooms-grid">
          <div v-for="room in rooms" :key="room.id" class="room-card">
            <div class="room-image">
              <!-- Dynamically bind the image URL with the base URL if necessary -->
              <img :src="getRoomImageUrl(room.image)" alt="Room Image" />
            </div>
  
            <div class="room-details">
              <h2>{{ room.name }}</h2>
              <p>Location: {{ room.location }}</p>
              <p>Price per hour: ${{ room.price }}</p>
              <p>Description: {{ room.description }}</p>
              
              <!-- Pay Now Button -->
              <button
                @click="initiatePayment(room.id)"
                class="pay-button"
              >
                Book Now
              </button>
  
              <!-- Request Room Button -->
              <!-- <button
                :disabled="room.isRequested"
                @click="requestRoom(room.id)"
                class="request-button"
              >
                Request Room
              </button> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import UserHeader from '@/components/UserHeader.vue';
  import axios from "@/utils/axios"; // Axios instance configured for CSRF and base URL
  
  export default {
    name: 'RoomsView',
    components: {
      UserHeader,
    },
    data() {
      return {
        rooms: [],
        loading: true,
        error: null,
        defaultImage: 'https://via.placeholder.com/150', // Placeholder image
      };
    },
    methods: {
      // Method to get the CSRF token from the cookies
      getCsrfToken() {
        const csrfToken = document.cookie.match(/csrftoken=([\w-]+)/)?.[1];
        return csrfToken;
      },
  
      // Fetch room data from backend
      async fetchRooms() {
        try {
          this.loading = true;
          const csrfToken = this.getCsrfToken(); // Get CSRF token
  
          const response = await axios.post('/graphql/', {
            query: `
              query {
                rooms {
                  id
                  name
                  price
                  location
                  description
                  capacity
                  image
                }
              }
            `,
          }, {
            headers: {
              'X-CSRFToken': csrfToken, // Include CSRF token in headers
            }
          });
  
          if (response.data.errors) {
            throw new Error(response.data.errors[0].message);
          }
          this.rooms = response.data.data.rooms;
        } catch (err) {
          this.error = err.message || 'Failed to fetch rooms.';
        } finally {
          this.loading = false;
        }
      },
  
      // Method to handle image URL path properly
      getRoomImageUrl(imagePath) {
        if (imagePath && imagePath.startsWith('/media/')) {
          return `${axios.defaults.baseURL}${imagePath}`; // Prepend base URL from Axios instance
        }
        return this.defaultImage; // Fallback to default image
      },
  
      // Initiate payment for a specific room
      async initiatePayment(roomId) {
    try {
      const csrfToken = this.getCsrfToken(); // Get CSRF token
  
      // Send a POST request to Django backend to create PayPal order
      const response = await axios.post('/create-order/', { roomId }, {
        headers: {
          'X-CSRFToken': csrfToken, // Include CSRF token in headers
        }
      });

      // Check if the backend returned the PayPal approval URL
      if (response.data.approval_url) {
        // Redirect to the paypal payment page
        window.location.href = response.data.approval_url;
      } else {
        // Handle any errors returned by the backend
        alert("Error: " + (response.data.error || "Failed to initiate payment."));
          }
        } catch (error) {
          console.error("Error:", error.response ? error.response.data : error.message);
        }
      },
  
      // Request a room (existing functionality)
      async requestRoom(roomId) {
        try {
          const csrfToken = this.getCsrfToken(); // Get CSRF token
  
          const response = await axios.post('/graphql/', {
            query: `
              mutation RequestRoom($roomId: Int!) {
                requestRoom(roomId: $roomId) {
                  success
                  message
                }
              }
            `,
            variables: { roomId },
          }, {
            headers: {
              'X-CSRFToken': csrfToken, // Include CSRF token in headers
            }
          });
  
          if (response.data.errors || !response.data.data.requestRoom.success) {
            throw new Error(
              response.data.errors
                ? response.data.errors[0].message
                : response.data.data.requestRoom.message
            );
          }
          alert('Room requested successfully!');
          this.fetchRooms();
        } catch (err) {
          alert(err.message || 'Failed to request the room.');
        }
      },
    },
    mounted() {
      this.fetchRooms();
    },
  };
  </script>
  
  
  <style scoped>
  .rooms-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    margin-top: 90px;
  }
  
  h1 {
    text-align: center;
    margin-bottom: 20px;
  }
  
  .rooms-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); /* Two cards per row */
    gap: 20px;
  }
  
  .room-card {
    display: flex;
    border: 1px solid #ccc;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    background-color: #fff;
  }
  
  .room-image {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #f9f9f9;
  }
  
  .room-image img {
    max-width: 100%;
    height: auto;
    border-radius: 8px 0 0 8px;
  }
  
  .room-details {
    flex: 2;
    padding: 15px;
  }
  
  .room-details h2 {
    margin: 0;
    font-size: 18px;
    font-weight: bold;
  }
  
  .pay-button {
    background-color: #28a745;
    color: white;
    border: none;
    padding: 10px 15px;
    cursor: pointer;
    border-radius: 5px;
    margin-right: 10px;
  }
  
  .pay-button:hover {
    background-color: #218838;
  }
  
  .request-button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 15px;
    cursor: pointer;
    border-radius: 5px;
  }
  
  .request-button:disabled {
    background-color: #ccc;
    cursor: not-allowed;
  }
  </style>
  