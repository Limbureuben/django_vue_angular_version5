<template>
    <div>
      <div v-if="loading">Verifying your email, please wait...</div>
      <div v-if="errorMessage" class="error">{{ errorMessage }}</div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        loading: true,
        errorMessage: null,
      };
    },
    mounted() {
      // Get the token from the URL params
      const token = this.$route.params.token;
  
      if (token) {
        // Make an HTTP GET request to the backend for token verification
        axios
          .get(`http://localhost:8000/verify-email/${token}/`)
          .then(() => {
            this.loading = false;
            this.$router.push({ name: 'login'}); // Redirect to login if successful
          })
          .catch(() => {
            this.loading = false;
            this.errorMessage = 'Verification failed. Please try again later.';
            this.$router.push({ name: 'login'}); // Redirect to login even if failed
          });
      } else {
        // Handle case where token is not provided
        this.loading = false;
        this.errorMessage = 'Invalid verification link.';
        this.$router.push({ name: 'login'}); // Redirect to login if invalid link
      }
    },
  };
  </script>
  
  <style scoped>
  .error {
    color: red;
  }
  </style>
  
  
  