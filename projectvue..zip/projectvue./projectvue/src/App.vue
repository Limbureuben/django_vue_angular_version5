<template>
  <div id="app">
   <RouterView/>
   </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  text-align: center;
  margin-top: 40px;
}
</style>
