import axios from 'axios';

class AuthService {
  static async login(username, password) {
    try {
      const response = await axios.post("http://192.168.1.124:8000/graphql/", {
        query: `
                    mutation {
                        loginUser(
                            input: {
                                username: "${username}",
                                password: "${password}"
                            }
                        ) {
                            message
                            success
                            user {
                                id
                                username
                                email
                                accessToken
                                refreshToken
                                isSuperuser
                            }
                        }
                    }
                `
            });
      // Ensure there is no error in the GraphQL response
      if (response.data.errors) {
        throw new Error(response.data.errors[0].message || 'Login failed');
      }

      return response.data.data;
    } catch (error) {
      console.error("Error during login:", error);
      throw new Error(error.message || 'Login failed');
    }
  }

  static isAuthenticated() {
    return !!localStorage.getItem("access_token");
  }

  static logout() {
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
  }
}

export default AuthService;
