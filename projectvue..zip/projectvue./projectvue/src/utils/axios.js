import axios from "axios";

// Set the base URL for all Axios requests
axios.defaults.baseURL = "http://localhost:8000"; // Update as needed

// Set the CSRF cookie and header names to match Django's default
axios.defaults.xsrfCookieName = "csrftoken";  // CSRF token name in cookies (default in Django)
axios.defaults.xsrfHeaderName = "X-CSRFToken"; // Header used for CSRF token (Django default)

// Enable credentials for cross-origin requests (important for CSRF token)
axios.defaults.withCredentials = true;

// Optional: Fetch CSRF token from backend to ensure it's available before making requests
axios.get('/get-csrf-token/')
  .then(() => {
    console.log("CSRF token set successfully.");
  })
  .catch((err) => {
    console.error("Failed to set CSRF token:", err);
  });

export default axios;

